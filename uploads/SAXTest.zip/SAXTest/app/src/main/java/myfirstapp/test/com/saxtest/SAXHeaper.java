package myfirstapp.test.com.saxtest;

import android.util.Log;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import java.util.ArrayList;

/**
 * Created by ck on 2016/7/6.
 */
public class SAXHeaper extends DefaultHandler {
    private String TagName;
    private Channel channel;
    private ArrayList<Channel> channels;
    @Override
    public void startDocument() throws SAXException {
        channels = new ArrayList<Channel>();
    }

    @Override
    public void endDocument() throws SAXException {
        Log.i("SAXHeaper",channels.toString());
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        TagName = localName;
        if(localName.equals("item")){
            channel = new Channel();
            Log.e("new","new");
        }
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        TagName = "";
        if(localName.equals("item")){
            channels.add(channel);
            Log.e("channel",channel.toString());
            channel = null;
        }

    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        String chars = new String(ch,start,length);
        if(TagName.equals("title")){
            channel.setTitle(chars);
        }else if(TagName.equals("link")){
            channel.setLink(chars);
        }else if(TagName.equals("category")){
            channel.setCategory(chars);
        }else if(TagName.equals("description")){
            channel.setDescription(chars);
        }else if(TagName.equals("pubDate")){
            channel.setPubDate(chars);
        }
    }
}
